---
name: Engineered Precision
colors:
  surface: '#111317'
  surface-dim: '#111317'
  surface-bright: '#37393e'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#1a1c20'
  surface-container: '#161920'
  surface-container-high: '#282a2e'
  surface-container-highest: '#333539'
  on-surface: '#e2e2e8'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e2e2e8'
  inverse-on-surface: '#2f3035'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#44e2cd'
  on-secondary: '#003731'
  secondary-container: '#03c6b2'
  on-secondary-container: '#004d44'
  tertiary: '#c3d000'
  on-tertiary: '#2f3300'
  tertiary-container: '#8e9800'
  on-tertiary-container: '#292c00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#62fae3'
  secondary-fixed-dim: '#3cddc7'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005047'
  tertiary-fixed: '#dfed1a'
  tertiary-fixed-dim: '#c3d000'
  on-tertiary-fixed: '#1b1d00'
  on-tertiary-fixed-variant: '#454a00'
  background: '#111317'
  on-background: '#e2e2e8'
  surface-variant: '#333539'
  surface-base: '#0F1115'
  border-subtle: '#242936'
  text-primary: '#F7F8F8'
  text-secondary: '#8A8F98'
typography:
  headline-xl:
    fontFamily: Geist
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter-desktop: 24px
  margin-desktop: 40px
  gutter-mobile: 16px
  margin-mobile: 16px
  max-width: 1280px
---

## Brand & Style

This design system is built for high-performance workflows and professional productivity tools. It embodies an **Engineered Modern** aesthetic—a fusion of Swiss minimalism with a high-fidelity technical edge. The visual language communicates speed, reliability, and sophistication.

The interface prioritizes clarity through deep tonal layering, crisp structural lines, and purposeful motion. It targets developers, designers, and power users who appreciate a UI that feels like a precision instrument. The emotional response is one of "focused calm," where the chrome of the application fades away to highlight the user's data and tasks.

## Colors

The color architecture is centered around a "Deep Slate" dark mode. Instead of pure black, the palette uses low-saturation charcoals to maintain better readability and reduce eye strain during long sessions.

- **Primary & Secondary:** A vibrant purple serves as the primary action color, while neon teal provides a sharp contrast for status indicators or secondary highlights.
- **Surface Hierarchy:** Depth is created through three distinct surface tiers. The base is the darkest, while interactive or floating containers use incrementally lighter grays.
- **Borders:** Crisp 1px borders are the primary method of separation, replacing heavy shadows to maintain a clean, architectural feel.

## Typography

The design system utilizes **Geist**, a typeface designed specifically for developers and precision interfaces. Its geometric construction and systematic spacing provide a clean, technical feel that remains legible even at small sizes.

- **Scale:** A tight typographic scale ensures information density without clutter.
- **Weight:** Medium (500) and SemiBold (600) weights are used primarily for hierarchy rather than decoration.
- **Letter Spacing:** Headlines utilize slight negative tracking for a "locked-in" editorial look, while small labels use increased tracking for legibility in all-caps scenarios.

## Layout & Spacing

The layout is built on a strict 4px baseline grid. All margins, padding, and component heights must be multiples of 4px to ensure mathematical alignment across the interface.

- **Grid:** A 12-column fluid grid is used for main content areas, transitioning to a 4-column layout on mobile.
- **Density:** The system favors a "Compact-Medium" density. Information is prioritized, but generous outer margins on desktop (40px) provide the "High-Fidelity" breathable feel.
- **Sidebars:** Persistent sidebars are fixed at 240px or 280px, while the main content area expands dynamically within its max-width container.

## Elevation & Depth

Depth is communicated through **Tonal Layering** and **Subtle Glassmorphism** rather than traditional heavy shadows.

- **Tiers:** 
  - **Level 0 (Base):** `#0F1115` - The application background.
  - **Level 1 (Surface):** `#161920` - Cards, sidebars, and primary navigation elements.
  - **Level 2 (Overlay):** Lightened surface with a 1px border at `#242936`. Used for modals and dropdowns.
- **Glassmorphism:** For floating menus and navigation bars, use a backdrop blur (20px) with a semi-transparent fill (`rgba(22, 25, 32, 0.7)`).
- **Borders:** Every container must have a 1px solid border using the `#242936` token. For interactive hover states, the border color should subtly brighten to a neutral gray.

## Shapes

The shape language is "Soft-Technical." We avoid aggressive rounding to maintain a professional, architectural structure.

- **Corner Radius:** A base radius of 4px (Soft) is used for inputs and buttons. Larger containers like cards use 8px (rounded-lg).
- **Consistency:** Use sharp corners only for dividers or full-bleed elements. All interactive components must have a radius to feel approachable yet precise.

## Components

### Buttons
- **Primary:** Background `#8B5CF6`, text white, 4px radius. Subtle top-inner highlight for a "tactile" feel.
- **Ghost:** No background, border `#242936`. On hover, background becomes `rgba(255, 255, 255, 0.05)`.

### Inputs
- **Style:** Background `#0F1115` with a 1px `#242936` border. 
- **Focus:** Border changes to the primary purple (`#8B5CF6`) with a subtle 2px outer glow (0.15 opacity).

### Cards
- **Construction:** Background `#161920`, 8px radius, 1px border `#242936`.
- **Interactivity:** On hover, cards should translate -2px on the Y-axis and the border should lighten.

### Chips/Tags
- **Visuals:** Small, semi-transparent backgrounds based on the accent color (e.g., `rgba(45, 212, 191, 0.1)` for Teal) with matching text color.

### Navigation
- **Active States:** Indicated by a vertical 2px pill on the left of the menu item in the primary purple color.